import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

async function seedDatabase() {
  const existingQuotes = await storage.getQuotes();
  if (existingQuotes.length === 0) {
    await storage.createQuote({
      type: "auto",
      riskLevel: "medium",
      value: 15000,
      price: 675 // 15000 * 0.03 * 1.5
    });
    await storage.createQuote({
      type: "health",
      riskLevel: "low",
      value: 100000,
      price: 5000 // 100000 * 0.05 * 1
    });
    await storage.createQuote({
      type: "property",
      riskLevel: "high",
      value: 250000,
      price: 6250 // 250000 * 0.01 * 2.5
    });
    console.log("Database seeded with initial quotes");
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Seed the database on startup
  seedDatabase().catch(console.error);

  app.get(api.quotes.list.path, async (req, res) => {
    const quotes = await storage.getQuotes();
    res.json(quotes);
  });

  app.post(api.quotes.create.path, async (req, res) => {
    try {
      const input = api.quotes.create.input.parse(req.body);
      
      // Calculate Price Logic
      let baseRate = 0.01; // 1% base for Property (default)
      
      if (input.type === 'auto') baseRate = 0.03;
      if (input.type === 'health') baseRate = 0.05;
      
      let riskMultiplier = 1;
      if (input.riskLevel === 'medium') riskMultiplier = 1.5;
      if (input.riskLevel === 'high') riskMultiplier = 2.5;
      
      // Basic calculation: Value * Rate * Risk
      const price = Math.round(input.value * baseRate * riskMultiplier);

      const quote = await storage.createQuote({ ...input, price });
      res.status(201).json(quote);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  return httpServer;
}
