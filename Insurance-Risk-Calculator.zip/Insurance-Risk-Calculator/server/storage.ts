import { db } from "./db";
import { quotes, type Quote, type InsertQuote } from "@shared/schema";

export interface IStorage {
  createQuote(quote: InsertQuote & { price: number }): Promise<Quote>;
  getQuotes(): Promise<Quote[]>;
}

export class DatabaseStorage implements IStorage {
  async createQuote(quote: InsertQuote & { price: number }): Promise<Quote> {
    const [newQuote] = await db.insert(quotes).values(quote).returning();
    return newQuote;
  }

  async getQuotes(): Promise<Quote[]> {
    return await db.select().from(quotes).orderBy(quotes.createdAt);
  }
}

export const storage = new DatabaseStorage();
