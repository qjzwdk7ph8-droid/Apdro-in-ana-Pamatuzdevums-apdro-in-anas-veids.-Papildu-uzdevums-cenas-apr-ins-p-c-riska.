import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const quotes = pgTable("quotes", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'health', 'property', 'auto'
  riskLevel: text("risk_level").notNull(), // 'low', 'medium', 'high'
  value: integer("value").notNull(), // Insured value
  price: integer("price").notNull(), // Calculated premium
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertQuoteSchema = createInsertSchema(quotes).omit({ 
  id: true, 
  createdAt: true,
  price: true // Price is calculated on backend
});

export type Quote = typeof quotes.$inferSelect;
export type InsertQuote = z.infer<typeof insertQuoteSchema>;

export type CreateQuoteRequest = InsertQuote;
export type QuoteResponse = Quote;
