import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertQuote, type QuoteResponse } from "@shared/routes"; // Assuming exports are available
import { useToast } from "@/hooks/use-toast";

// Fetch all quotes
export function useQuotes() {
  return useQuery({
    queryKey: [api.quotes.list.path],
    queryFn: async () => {
      const res = await fetch(api.quotes.list.path);
      if (!res.ok) throw new Error("Failed to fetch quotes");
      return await res.json() as QuoteResponse[];
    },
  });
}

// Create a new quote calculation
export function useCreateQuote() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertQuote) => {
      const res = await fetch(api.quotes.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to calculate premium");
      }
      
      return await res.json() as QuoteResponse;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
      toast({
        title: "Calculation Complete",
        description: `Estimated Premium: $${data.price}`,
        variant: "default", // Success style handled by toaster
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Calculation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
