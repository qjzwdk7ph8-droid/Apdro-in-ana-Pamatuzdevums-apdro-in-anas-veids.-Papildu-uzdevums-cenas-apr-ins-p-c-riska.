import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertQuoteSchema } from "@shared/schema";
import { useCreateQuote } from "@/hooks/use-quotes";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Calculator, Loader2, DollarSign } from "lucide-react";
import { useState } from "react";
import { motion } from "framer-motion";

// Extend the schema to handle string inputs from form that need coercion
const formSchema = insertQuoteSchema.extend({
  value: z.coerce.number().min(1, "Value must be greater than 0"),
});

type FormValues = z.infer<typeof formSchema>;

export function CalculatorForm() {
  const { mutate, isPending } = useCreateQuote();
  const [lastResult, setLastResult] = useState<number | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type: "health",
      riskLevel: "low",
      value: 10000,
    },
  });

  function onSubmit(data: FormValues) {
    mutate(data, {
      onSuccess: (result) => {
        setLastResult(result.price);
        // Scroll to result on mobile if needed, or trigger nice animation
      },
    });
  }

  return (
    <Card className="border-none shadow-xl bg-white relative overflow-hidden">
      {/* Decorative gradient blob */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" />

      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <div className="p-3 bg-primary rounded-xl shadow-lg shadow-primary/25">
            <Calculator className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold">Premium Calculator</CardTitle>
            <CardDescription>Get an instant quote based on your risk profile</CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="relative z-10">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Insurance Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="h-12 text-lg">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="health">Health Insurance</SelectItem>
                        <SelectItem value="property">Property Insurance</SelectItem>
                        <SelectItem value="auto">Auto Insurance</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="riskLevel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Assessment</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="h-12 text-lg">
                          <SelectValue placeholder="Select risk level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low Risk</SelectItem>
                        <SelectItem value="medium">Medium Risk</SelectItem>
                        <SelectItem value="high">High Risk</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="value"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Insured Value ($)</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
                      <Input 
                        type="number" 
                        {...field} 
                        className="pl-10 h-12 text-lg font-mono"
                        placeholder="10000"
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <motion.div whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }}>
              <Button 
                type="submit" 
                className="w-full h-14 text-lg font-bold shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all"
                disabled={isPending}
              >
                {isPending ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Calculating...
                  </>
                ) : (
                  "Calculate Premium"
                )}
              </Button>
            </motion.div>
          </form>
        </Form>

        {lastResult !== null && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 p-6 bg-slate-900 rounded-2xl text-center text-white relative overflow-hidden"
          >
            <div className="relative z-10">
              <p className="text-slate-400 font-medium mb-1">Estimated Annual Premium</p>
              <div className="text-5xl font-bold tracking-tight text-white mb-2">
                ${lastResult.toLocaleString()}
              </div>
              <p className="text-sm text-slate-400">
                Based on your current selection. <br/> This is an estimate, not a final offer.
              </p>
            </div>
            {/* Background effects */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 rounded-full blur-2xl" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-purple-500/20 rounded-full blur-2xl" />
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}
