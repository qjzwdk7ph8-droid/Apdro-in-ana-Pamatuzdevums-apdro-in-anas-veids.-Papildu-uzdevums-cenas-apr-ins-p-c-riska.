import { useQuotes } from "@/hooks/use-quotes";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Shield, Car, Home, TrendingUp, AlertTriangle, CheckCircle2 } from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { motion, AnimatePresence } from "framer-motion";

export function QuoteHistory() {
  const { data: quotes, isLoading } = useQuotes();

  if (isLoading) {
    return <HistorySkeleton />;
  }

  const sortedQuotes = quotes ? [...quotes].sort((a, b) => 
    new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
  ) : [];

  return (
    <Card className="h-full border-none shadow-lg bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="p-2 bg-primary/10 rounded-lg">
            <TrendingUp className="w-5 h-5 text-primary" />
          </div>
          <CardTitle className="text-xl">Recent Calculations</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[500px] pr-4">
          <div className="space-y-4">
            <AnimatePresence>
              {sortedQuotes.length === 0 ? (
                <EmptyState />
              ) : (
                sortedQuotes.map((quote, index) => (
                  <motion.div
                    key={quote.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <div className="group relative overflow-hidden rounded-xl border border-border/50 bg-background p-4 hover:border-primary/50 hover:shadow-md transition-all duration-300">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <QuoteIcon type={quote.type} />
                          <div>
                            <p className="font-semibold capitalize text-foreground">
                              {quote.type} Insurance
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Valued at ${quote.value.toLocaleString()}
                            </p>
                            <div className="mt-2 flex gap-2">
                              <RiskBadge level={quote.riskLevel} />
                              <span className="text-xs text-muted-foreground self-center">
                                {quote.createdAt && format(new Date(quote.createdAt), "MMM d, h:mm a")}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Premium</p>
                          <p className="text-xl font-bold text-primary">
                            ${quote.price.toLocaleString()}
                          </p>
                          <span className="text-xs text-muted-foreground">/year</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

function HistorySkeleton() {
  return (
    <Card className="h-full border-none shadow-lg">
      <CardHeader>
        <Skeleton className="h-8 w-48" />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-24 w-full rounded-xl" />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
      <Shield className="w-12 h-12 mb-4 opacity-20" />
      <p>No calculations yet.</p>
      <p className="text-sm">Start by filling out the form.</p>
    </div>
  );
}

function QuoteIcon({ type }: { type: string }) {
  const className = "w-10 h-10 rounded-full flex items-center justify-center shrink-0";
  
  switch (type) {
    case 'auto':
      return <div className={`${className} bg-blue-100 text-blue-600`}><Car className="w-5 h-5" /></div>;
    case 'property':
      return <div className={`${className} bg-emerald-100 text-emerald-600`}><Home className="w-5 h-5" /></div>;
    case 'health':
      return <div className={`${className} bg-rose-100 text-rose-600`}><Shield className="w-5 h-5" /></div>;
    default:
      return <div className={`${className} bg-gray-100 text-gray-600`}><Shield className="w-5 h-5" /></div>;
  }
}

function RiskBadge({ level }: { level: string }) {
  const styles = {
    low: "bg-emerald-100 text-emerald-700 hover:bg-emerald-200 border-emerald-200",
    medium: "bg-yellow-100 text-yellow-700 hover:bg-yellow-200 border-yellow-200",
    high: "bg-red-100 text-red-700 hover:bg-red-200 border-red-200",
  };

  const icons = {
    low: <CheckCircle2 className="w-3 h-3 mr-1" />,
    medium: <AlertTriangle className="w-3 h-3 mr-1" />,
    high: <AlertTriangle className="w-3 h-3 mr-1" />,
  };

  const key = level as keyof typeof styles;

  return (
    <Badge variant="outline" className={`${styles[key] || styles.medium} px-2 py-0.5 capitalize transition-colors`}>
      {icons[key]} {level} Risk
    </Badge>
  );
}
