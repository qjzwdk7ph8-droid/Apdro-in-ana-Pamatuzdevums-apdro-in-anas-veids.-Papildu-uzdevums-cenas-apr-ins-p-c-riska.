## Packages
framer-motion | Smooth animations for form steps and results
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes efficiently

## Notes
- The app uses a "FinTech" aesthetic with deep blues and crisp whites.
- Real-time calculation feedback is provided via the POST endpoint.
- History is automatically updated upon successful calculation.
